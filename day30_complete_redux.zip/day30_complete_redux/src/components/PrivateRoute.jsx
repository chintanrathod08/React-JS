import React from 'react'

function PrivateRoute() {
  return (
    <div>
      
    </div>
  )
}

export default PrivateRoute
