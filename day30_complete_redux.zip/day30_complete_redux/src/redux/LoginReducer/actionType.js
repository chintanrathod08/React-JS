export const LOGLOADING = "LOGLOADING"
export const LOGSUCCESS = "LOGSUCCESS"
export const LOGERROR = "LOGERROR"
