import React from 'react'
import { useSelector } from 'react-redux'

function Home() {
  
  return (
    <div>
       <center> <h1>Home</h1> </center>
    </div>
  )
}

export default Home